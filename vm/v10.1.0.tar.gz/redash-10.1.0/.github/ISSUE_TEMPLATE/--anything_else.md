---
name: "\U0001F4A1Anything else"
about: "For help, support, features & ideas - please use https://discuss.redash.io \U0001F46B "
labels: "Support Question"
---

We use GitHub only for bug reports 🐛

Anything else should be posted to https://discuss.redash.io 👫

🚨For support, help & questions use https://discuss.redash.io/c/support
💡For feature requests & ideas use https://discuss.redash.io/c/feature-requests

Alternatively, check out these resources below. Thanks! 😁.

- [Forum](https://disucss.redash.io)
- [Knowledge Base](https://redash.io/help)
